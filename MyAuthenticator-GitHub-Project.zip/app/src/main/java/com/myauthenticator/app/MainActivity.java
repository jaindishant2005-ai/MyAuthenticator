package com.myauthenticator.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    TextView code, timer;
    String secret = null;
    Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        code = findViewById(R.id.code);
        timer = findViewById(R.id.timer);
        Button add = findViewById(R.id.addButton);

        secret = getPreferences(MODE_PRIVATE).getString("secret", null);
        add.setOnClickListener(v -> addSecret());

        handler.post(tick);
    }

    void addSecret() {
        final EditText input = new EditText(this);
        input.setHint("Base32 secret");
        new AlertDialog.Builder(this)
            .setTitle("Add TOTP account")
            .setMessage("Enter the TOTP setup secret provided by the service.")
            .setView(input)
            .setPositiveButton("Save", (d,w) -> {
                String s = input.getText().toString().replace(" ", "").toUpperCase();
                if (!s.isEmpty()) {
                    secret = s;
                    getPreferences(MODE_PRIVATE).edit().putString("secret", secret).apply();
                }
            })
            .setNegativeButton("Cancel", null).show();
    }

    Runnable tick = new Runnable() {
        public void run() {
            long seconds = System.currentTimeMillis()/1000L;
            int remain = (int)(30 - (seconds % 30));
            timer.setText(remain + "s");
            if (secret != null) {
                try { code.setText(makeTotp(secret, seconds/30)); }
                catch(Exception e) { code.setText("ERROR"); }
            } else code.setText("------");
            handler.postDelayed(this, 500);
        }
    };

    static String makeTotp(String base32, long counter) throws Exception {
        byte[] key = base32Decode(base32);
        byte[] msg = ByteBuffer.allocate(8).putLong(counter).array();
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(key, "HmacSHA1"));
        byte[] hash = mac.doFinal(msg);
        int offset = hash[hash.length-1] & 0x0f;
        int bin = ((hash[offset]&0x7f)<<24)|((hash[offset+1]&0xff)<<16)|
                  ((hash[offset+2]&0xff)<<8)|(hash[offset+3]&0xff);
        return String.format("%06d", bin % 1000000);
    }

    static byte[] base32Decode(String s) {
        s = s.replace("=", "");
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        int buffer=0,bits=0;
        for(char c:s.toCharArray()) {
            int v = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".indexOf(c);
            if(v < 0) continue;
            buffer=(buffer<<5)|v; bits+=5;
            if(bits>=8) { bits-=8; out.write((buffer>>bits)&255); }
        }
        return out.toByteArray();
    }
}
